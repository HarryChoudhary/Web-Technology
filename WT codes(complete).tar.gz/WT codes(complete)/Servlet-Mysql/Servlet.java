import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String url, user_name, password;

	public Servlet() {
		// TODO Auto-generated constructor stub
		url = "jdbc:mysql://localhost:3306/wt";
		user_name = "root";
		password = "root";
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		response.setContentType("text/HTML");
		String usr = request.getParameter("User_name");
		String pass = request.getParameter("Password");
		String eml = request.getParameter("Email_id");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection connec = DriverManager.getConnection(url, user_name, password);
			out.println("Connection successful");
			java.sql.Statement str = connec.createStatement();
			String input = request.getParameter("action");
			if (input.equals("insert")) {
				out.print("<h2>Insertion operation</h2>");
				int chk = str
						.executeUpdate("insert into Login_cred values('" + usr + "','" + pass + "','" + eml + "')");
				if (chk > 0)
					out.println("Insertion successful.");
				else
					out.println("Insertion failed.");
			} else if (input.equals("delete")) {
				out.print("<h2>deletion operation</h2>");
				String update_query_1 = "delete from Login_cred where User_name = '" + usr + "'";
				int chk = str.executeUpdate(update_query_1);
				if (chk > 0)
					out.println("deletion successful.");
				else
					out.println("deletion failed.");
			} else if (input.equals("update")) {
				out.print("<h2>update operation</h2>");
				String update_query_2 = "update Login_cred set Password = ?,Email = ? where User_name = '" + usr + "'";
				java.sql.PreparedStatement p = connec.prepareStatement(update_query_2);
				p.setString(1, pass);
				p.setString(2, eml);
				int chk = p.executeUpdate();
				if (chk > 0)
					out.println("updation successful.");
				else
					out.println("updation failed.");
			} else if (input.equals("display")) {
				out.print("<h2>display operation</h2>");
				String update_query_3 = "select * from Login_cred";
				java.sql.PreparedStatement p = connec.prepareStatement(update_query_3);
				ResultSet rs = p.executeQuery();
				String name, password, mail;
				out.print("<table>");
				out.print("<tr>" + "<th>User_Name</th>" + "<th>Password</th>" + "<th>Email_id</th>" + "</tr>");
				while (rs.next()) {
					name = rs.getString(1);
					password = rs.getString(2);
					mail = rs.getString(3);
					out.print("<tr><td>" + name + "</td><td>" + password + "</td><td>" + mail + "</td></tr>");
				}
				out.print("</table>");
			}
		} catch (Exception e) {
			out.println(e);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}