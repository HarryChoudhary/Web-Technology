<?php 
$server_name = "localhost";
$user_name = "root";
$password = "root";
$database_name = "wt";
$user = $_POST["User_name"];
$pass = $_POST["Password"];
$eml = $_POST["Email_id"];
$con = new mysqli($server_name,$user_name,$password,$database_name);
if($con->connect_error){
	die("Failed");
}
else {
	echo("Connection successful");
	$input = $_POST["action"];
	if($input == "insert"){
		$sql = "insert into Login_cred values('$user','$pass','$eml')";
		if($con->query($sql)===TRUE)
			echo("record inserted Successfully...!");
		else
			echo("Error :".$sql.$con->error);}	
	else if($input == "delete"){
		$sql = "delete from Login_cred where User_name ='$user'";
		if($con->query($sql)===TRUE)
			echo("record deleted Successfully...!");
		else
			echo("Error :".$sql.$con->error);}	
	else if($input == "update"){
		$sql = "update Login_cred set Password = '$pass' where User_name = '$user'";
		if($con->query($sql)===TRUE)
			echo("record updated Successfully...!");
		else
			echo("Error :".$sql.$con->error);}	
	else if($input == "display"){
		$sql = "select * from Login_cred";
		$result = $con->query($sql);
		if($result->num_rows > 0){
			while($row = $result->fetch_assoc())
				echo("User_Name :" .$row["User_name"]. " Password :" .$row["Password"]. " Email_id :" .$row["Email"]);
				}
		else
			echo("Error :".$sql.$con->error);}				
}
?>
